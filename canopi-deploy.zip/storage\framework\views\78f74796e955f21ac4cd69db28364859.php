

<?php $__env->startSection('page-title', 'Karyawan'); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('partials.sidebar-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-nav'); ?>
    <?php echo $__env->make('partials.bottomnav-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;flex-direction:column;gap:16px;">

    
    <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;">
        <div>
            <h2 style="font-size:18px;font-weight:700;margin:0;" :style="darkMode ? 'color:#F1F5F9' : 'color:#1E293B'">Data Karyawan</h2>
            <p style="font-size:12px;color:#94A3B8;margin:4px 0 0 0;">Total <?php echo e($karyawan->total()); ?> karyawan terdaftar</p>
        </div>
        <?php if(auth()->user()->level == 1 || auth()->user()->level == 2): ?>
        <a href="<?php echo e(route('karyawan.create')); ?>"
           style="display:flex;align-items:center;gap:6px;padding:10px 18px;border-radius:10px;font-size:13px;font-weight:600;text-decoration:none;color:#0F1117;background:linear-gradient(135deg,#C9A84C,#A8872E);">
            <svg xmlns="http://www.w3.org/2000/svg" style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M12 4.5v15m7.5-7.5h-15"/>
            </svg>
            Tambah Karyawan
        </a>
        <?php endif; ?>
    </div>

    
    <form method="GET" action="<?php echo e(route('karyawan.index')); ?>">
        <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <input type="text" name="search" value="<?php echo e(request('search')); ?>"
                   placeholder="🔍 Cari nama..."
                   style="flex:1;min-width:160px;padding:10px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                   :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">

            <select name="level"
                    style="padding:10px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;cursor:pointer;"
                    :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                <option value="">Semua Level</option>
                <?php $__currentLoopData = [1=>'Owner',2=>'Admin Ops',3=>'Supervisor',4=>'Marketing',5=>'Teknisi',6=>'Driver',7=>'Admin Toko']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($l); ?>" <?php echo e(request('level') == $l ? 'selected' : ''); ?>><?php echo e($n); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <select name="status"
                    style="padding:10px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;cursor:pointer;"
                    :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                <option value="">Semua Status</option>
                <option value="aktif" <?php echo e(request('status') == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                <option value="sp1" <?php echo e(request('status') == 'sp1' ? 'selected' : ''); ?>>SP 1</option>
                <option value="sp2" <?php echo e(request('status') == 'sp2' ? 'selected' : ''); ?>>SP 2</option>
                <option value="sp3" <?php echo e(request('status') == 'sp3' ? 'selected' : ''); ?>>SP 3</option>
                <option value="nonaktif" <?php echo e(request('status') == 'nonaktif' ? 'selected' : ''); ?>>Nonaktif</option>
            </select>

            <button type="submit" style="padding:10px 16px;border-radius:10px;font-size:13px;font-weight:600;border:none;cursor:pointer;color:#0F1117;background:linear-gradient(135deg,#C9A84C,#A8872E);">
                Filter
            </button>
        </div>
    </form>

    
    <div style="display:flex;flex-direction:column;gap:10px;">
        <?php $__empty_1 = true; $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('karyawan.show', $k)); ?>" style="text-decoration:none;">
            <div class="stat-card" style="display:flex;align-items:center;gap:14px;padding:14px 16px;cursor:pointer;transition:all 0.2s;"
                 onmouseover="this.style.transform='translateY(-1px)'" onmouseout="this.style.transform='translateY(0)'">

                
                <div style="width:44px;height:44px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:700;flex-shrink:0;color:white;background:linear-gradient(135deg,#C9A84C,#A8872E);">
                    <?php if($k->foto): ?>
                        <img src="<?php echo e(Storage::url($k->foto)); ?>" style="width:44px;height:44px;border-radius:12px;object-fit:cover;">
                    <?php else: ?>
                        <?php echo e(strtoupper(substr($k->name, 0, 1))); ?>

                    <?php endif; ?>
                </div>

                
                <div style="flex:1;min-width:0;">
                    <div style="font-size:14px;font-weight:600;margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"
                         :style="darkMode ? 'color:#F1F5F9' : 'color:#1E293B'">
                        <?php echo e($k->name); ?>

                    </div>
                    <div style="font-size:12px;color:#94A3B8;"><?php echo e($k->jabatan ?? $levels[$k->level]); ?></div>
                </div>

                
                <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;flex-shrink:0;">
                    <span style="font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;background:<?php echo e($k->warnStatus()); ?>20;color:<?php echo e($k->warnStatus()); ?>;border:1px solid <?php echo e($k->warnStatus()); ?>40;">
                        <?php echo e($k->labelStatus()); ?>

                    </span>
                    <span style="font-size:10px;color:#64748B;"><?php echo e($levels[$k->level] ?? ''); ?></span>
                </div>

                
                <svg xmlns="http://www.w3.org/2000/svg" style="width:16px;height:16px;color:#64748B;flex-shrink:0;" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5"/>
                </svg>
            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="stat-card" style="text-align:center;padding:40px;">
            <div style="font-size:32px;margin-bottom:12px;">👥</div>
            <div style="font-size:14px;font-weight:600;margin-bottom:4px;" :style="darkMode ? 'color:#94A3B8' : 'color:#64748B'">Belum ada karyawan</div>
            <div style="font-size:12px;color:#94A3B8;">Tambah karyawan pertama dengan tombol di atas</div>
        </div>
        <?php endif; ?>
    </div>

    
    <?php if($karyawan->hasPages()): ?>
    <div style="display:flex;justify-content:center;">
        <?php echo e($karyawan->links()); ?>

    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\canopi-app\resources\views/karyawan/index.blade.php ENDPATH**/ ?>