

<?php $__env->startSection('page-title', $karyawan->name); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('partials.sidebar-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-nav'); ?>
    <?php echo $__env->make('partials.bottomnav-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:680px;margin:0 auto;">

    
    <a href="<?php echo e(route('karyawan.index')); ?>" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;color:#94A3B8;text-decoration:none;margin-bottom:20px;">
        <svg xmlns="http://www.w3.org/2000/svg" style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"/>
        </svg>
        Kembali
    </a>

    
    <div class="stat-card" style="margin-bottom:16px;text-align:center;padding:28px;">
        
        <div style="width:80px;height:80px;border-radius:50%;margin:0 auto 16px;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;background:linear-gradient(135deg,#C9A84C,#A8872E);color:white;overflow:hidden;">
            <?php if($karyawan->foto): ?>
                <img src="<?php echo e(Storage::url($karyawan->foto)); ?>" style="width:100%;height:100%;object-fit:cover;">
            <?php else: ?>
                <?php echo e(strtoupper(substr($karyawan->name, 0, 1))); ?>

            <?php endif; ?>
        </div>

        <h2 style="font-size:20px;font-weight:700;margin:0 0 6px 0;" :style="darkMode ? 'color:#F1F5F9' : 'color:#1E293B'">
            <?php echo e($karyawan->name); ?>

        </h2>
        <div style="font-size:13px;color:#94A3B8;margin-bottom:12px;"><?php echo e($karyawan->jabatan ?? $levels[$karyawan->level]); ?></div>

        <div style="display:flex;align-items:center;justify-content:center;gap:8px;">
            <span style="font-size:11px;font-weight:700;padding:4px 12px;border-radius:20px;background:<?php echo e($karyawan->warnStatus()); ?>20;color:<?php echo e($karyawan->warnStatus()); ?>;border:1px solid <?php echo e($karyawan->warnStatus()); ?>40;">
                <?php echo e($karyawan->labelStatus()); ?>

            </span>
            <span style="font-size:11px;padding:4px 12px;border-radius:20px;background:rgba(201,168,76,0.1);color:#C9A84C;border:1px solid rgba(201,168,76,0.3);">
                <?php echo e($levels[$karyawan->level] ?? ''); ?>

            </span>
        </div>
    </div>

    
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
        <?php
        $infos = [
            ['label'=>'Email','value'=>$karyawan->email,'icon'=>'📧'],
            ['label'=>'No. HP','value'=>$karyawan->no_hp ?? '-','icon'=>'📱'],
            ['label'=>'Masuk Kerja','value'=>$karyawan->tgl_masuk_kerja ? $karyawan->tgl_masuk_kerja->format('d M Y') : '-','icon'=>'📅'],
            ['label'=>'Masa Kerja','value'=>$karyawan->masaKerja(),'icon'=>'⏱️'],
            ['label'=>'Jam Masuk','value'=>$karyawan->jam_masuk,'icon'=>'⏰'],
            ['label'=>'Jam Pulang','value'=>$karyawan->jam_pulang,'icon'=>'🏠'],
        ];
        ?>
        <?php $__currentLoopData = $infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="stat-card" style="padding:14px 16px;">
            <div style="font-size:18px;margin-bottom:4px;"><?php echo e($info['icon']); ?></div>
            <div style="font-size:11px;color:#94A3B8;margin-bottom:2px;"><?php echo e($info['label']); ?></div>
            <div style="font-size:13px;font-weight:600;word-break:break-all;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'"><?php echo e($info['value']); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <?php if($karyawan->alamat): ?>
    <div class="stat-card" style="margin-bottom:16px;">
        <div style="font-size:12px;color:#94A3B8;margin-bottom:4px;">📍 Alamat</div>
        <div style="font-size:13px;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'"><?php echo e($karyawan->alamat); ?></div>
    </div>
    <?php endif; ?>

    
    <?php if(auth()->user()->level == 1): ?>
    <div class="stat-card" style="margin-bottom:16px;">
        <h3 style="font-size:13px;font-weight:700;margin:0 0 16px 0;" :style="darkMode ? 'color:#F1F5F9' : 'color:#1E293B'">💰 Data Gaji</h3>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <div>
                <div style="font-size:11px;color:#94A3B8;margin-bottom:2px;">Tipe Gaji</div>
                <div style="font-size:13px;font-weight:600;color:#C9A84C;"><?php echo e(ucfirst($karyawan->tipe_gaji)); ?></div>
            </div>
            <div>
                <div style="font-size:11px;color:#94A3B8;margin-bottom:2px;">Gaji Harian</div>
                <div style="font-size:13px;font-weight:600;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'">Rp <?php echo e(number_format($karyawan->gaji_harian, 0, ',', '.')); ?></div>
            </div>
            <div>
                <div style="font-size:11px;color:#94A3B8;margin-bottom:2px;">Gaji Bulanan</div>
                <div style="font-size:13px;font-weight:600;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'">Rp <?php echo e(number_format($karyawan->gaji_bulanan, 0, ',', '.')); ?></div>
            </div>
            <div>
                <div style="font-size:11px;color:#94A3B8;margin-bottom:2px;">Uang Makan/Hari</div>
                <div style="font-size:13px;font-weight:600;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'">Rp <?php echo e(number_format($karyawan->uang_makan, 0, ',', '.')); ?></div>
            </div>
        </div>

        <?php if($karyawan->tunjangan->count() > 0): ?>
        <div style="margin-top:16px;padding-top:16px;border-top:1px solid;" :style="darkMode ? 'border-color:rgba(255,255,255,0.06)' : 'border-color:#F1F5F9'">
            <div style="font-size:11px;color:#94A3B8;margin-bottom:10px;">Tunjangan</div>
            <?php $__currentLoopData = $karyawan->tunjangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid;" :style="darkMode ? 'border-color:rgba(255,255,255,0.04)' : 'border-color:#F8FAFC'">
                <span style="font-size:12px;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'"><?php echo e($t->nama_tunjangan); ?></span>
                <span style="font-size:12px;font-weight:600;color:#C9A84C;">Rp <?php echo e(number_format($t->pivot->nominal, 0, ',', '.')); ?></span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    
    <?php if($karyawan->no_rekening): ?>
    <div class="stat-card" style="margin-bottom:16px;">
        <h3 style="font-size:13px;font-weight:700;margin:0 0 12px 0;" :style="darkMode ? 'color:#F1F5F9' : 'color:#1E293B'">🏦 Rekening Bank</h3>
        <div style="display:flex;align-items:center;gap:12px;">
            <div style="width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;background:rgba(201,168,76,0.1);">🏦</div>
            <div>
                <div style="font-size:14px;font-weight:700;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'"><?php echo e($karyawan->nama_bank); ?></div>
                <div style="font-size:13px;color:#94A3B8;"><?php echo e($karyawan->no_rekening); ?> · a.n <?php echo e($karyawan->atas_nama); ?></div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if(auth()->user()->level == 1): ?>
    <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:16px;">
        <a href="<?php echo e(route('karyawan.edit', $karyawan)); ?>"
           style="display:flex;align-items:center;justify-content:center;gap:8px;padding:14px;border-radius:12px;font-size:13px;font-weight:700;text-decoration:none;color:#0F1117;background:linear-gradient(135deg,#C9A84C,#A8872E);">
            <svg xmlns="http://www.w3.org/2000/svg" style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125"/>
            </svg>
            Edit Data Karyawan
        </a>

        
        <div x-data="{ showReset: false }">
            <button @click="showReset = !showReset"
                    style="width:100%;padding:12px;border-radius:12px;font-size:13px;font-weight:600;border:1.5px solid;cursor:pointer;background:transparent;"
                    :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#94A3B8' : 'border-color:#E2E8F0;color:#64748B'">
                🔑 Reset Password
            </button>

            <div x-show="showReset" x-transition style="margin-top:10px;">
                <form method="POST" action="<?php echo e(route('karyawan.reset-password', $karyawan)); ?>">
                    <?php echo csrf_field(); ?>
                    <div style="margin-bottom:10px;">
                        <input type="password" name="password" placeholder="Password baru (min 6 karakter)" required
                               style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                               :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                    </div>
                    <div style="margin-bottom:10px;">
                        <input type="password" name="password_confirmation" placeholder="Konfirmasi password baru" required
                               style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                               :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                    </div>
                    <button type="submit" style="width:100%;padding:12px;border-radius:10px;font-size:13px;font-weight:700;border:none;cursor:pointer;color:white;background:#3B82F6;">
                        Simpan Password Baru
                    </button>
                </form>
            </div>
        </div>

        
        <?php if($karyawan->status != 'nonaktif'): ?>
        <form method="POST" action="<?php echo e(route('karyawan.nonaktifkan', $karyawan)); ?>"
              onsubmit="return confirm('Yakin nonaktifkan <?php echo e($karyawan->name); ?>?')">
            <?php echo csrf_field(); ?>
            <button type="submit" style="width:100%;padding:12px;border-radius:12px;font-size:13px;font-weight:600;border:none;cursor:pointer;color:#EF4444;background:rgba(239,68,68,0.1);">
                ⚠️ Nonaktifkan Karyawan
            </button>
        </form>
        <?php else: ?>
        <form method="POST" action="<?php echo e(route('karyawan.aktifkan', $karyawan)); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" style="width:100%;padding:12px;border-radius:12px;font-size:13px;font-weight:600;border:none;cursor:pointer;color:#10B981;background:rgba(16,185,129,0.1);">
                ✅ Aktifkan Kembali
            </button>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\canopi-app\resources\views/karyawan/show.blade.php ENDPATH**/ ?>