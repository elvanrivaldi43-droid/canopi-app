<?php $__env->startSection('page-title', 'Absensi'); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('partials.sidebar-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-nav'); ?>
    <?php echo $__env->make('partials.bottomnav-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;flex-direction:column;gap:16px;max-width:600px;margin:0 auto;">

    
    <?php if(session('success')): ?>
    <div style="padding:14px 16px;border-radius:12px;background:rgba(16,185,129,0.12);border:1px solid rgba(16,185,129,0.3);font-size:13px;color:#10B981;display:flex;align-items:center;gap:10px;">
        <span style="font-size:18px;">✅</span> <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
    <div style="padding:14px 16px;border-radius:12px;background:rgba(239,68,68,0.12);border:1px solid rgba(239,68,68,0.3);font-size:13px;color:#F87171;display:flex;align-items:center;gap:10px;">
        <span style="font-size:18px;">⚠️</span> <?php echo e(session('error')); ?>

    </div>
    <?php endif; ?>

    
    <div style="border-radius:16px;padding:20px;background:linear-gradient(135deg,#0F1117 0%,#1E2535 100%);border:1px solid rgba(201,168,76,0.2);">
        <p style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#C9A84C;margin:0 0 4px 0;">
            <?php echo e(now()->isoFormat('dddd, D MMMM Y')); ?>

        </p>
        <h2 style="font-size:18px;font-weight:700;color:white;margin:0 0 16px 0;">Status Hari Ini</h2>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
            
            <div style="padding:14px;border-radius:12px;background:rgba(255,255,255,0.05);text-align:center;">
                <div style="font-size:22px;margin-bottom:6px;">🏢</div>
                <div style="font-size:11px;color:#64748B;margin-bottom:4px;">JAM MASUK</div>
                <div style="font-size:16px;font-weight:700;color:<?php echo e($absenHariIni?->jam_masuk ? '#10B981' : '#64748B'); ?>;">
                    <?php echo e($absenHariIni?->jam_masuk ? substr($absenHariIni->jam_masuk, 0, 5) : '--:--'); ?>

                </div>
            </div>
            
            <div style="padding:14px;border-radius:12px;background:rgba(255,255,255,0.05);text-align:center;">
                <div style="font-size:22px;margin-bottom:6px;">🏠</div>
                <div style="font-size:11px;color:#64748B;margin-bottom:4px;">JAM PULANG</div>
                <div style="font-size:16px;font-weight:700;color:<?php echo e($absenHariIni?->jam_pulang ? '#10B981' : '#64748B'); ?>;">
                    <?php echo e($absenHariIni?->jam_pulang ? substr($absenHariIni->jam_pulang, 0, 5) : '--:--'); ?>

                </div>
            </div>
        </div>

        
        <?php if(!$absenHariIni || !$absenHariIni->jam_masuk): ?>
        <a href="<?php echo e(route('absensi.form-masuk')); ?>"
           style="display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:16px;border-radius:14px;font-size:15px;font-weight:700;text-decoration:none;color:#0F1117;background:linear-gradient(135deg,#C9A84C,#A8872E);min-height:54px;">
            📷 ABSEN MASUK SEKARANG
        </a>
        <?php elseif($absenHariIni->jam_masuk && !$absenHariIni->jam_pulang): ?>
        <div style="display:flex;flex-direction:column;gap:10px;">
            <div style="padding:10px 14px;border-radius:10px;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);font-size:13px;color:#10B981;text-align:center;">
                ✅ Sudah absen masuk pukul <?php echo e(substr($absenHariIni->jam_masuk, 0, 5)); ?>

                <?php if($absenHariIni->status === 'telat'): ?>
                · <span style="color:#F59E0B;">⏰ Telat</span>
                <?php endif; ?>
            </div>
            <a href="<?php echo e(route('absensi.form-pulang')); ?>"
               style="display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:16px;border-radius:14px;font-size:15px;font-weight:700;text-decoration:none;color:white;background:linear-gradient(135deg,#3B82F6,#1D4ED8);min-height:54px;">
                🏠 ABSEN PULANG SEKARANG
            </a>
        </div>
        <?php else: ?>
        <div style="padding:14px;border-radius:12px;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);text-align:center;">
            <div style="font-size:22px;margin-bottom:6px;">🎉</div>
            <div style="font-size:14px;font-weight:700;color:#10B981;">Absensi Hari Ini Lengkap</div>
            <div style="font-size:12px;color:#64748B;margin-top:4px;">
                <?php echo e(substr($absenHariIni->jam_masuk, 0, 5)); ?> – <?php echo e(substr($absenHariIni->jam_pulang, 0, 5)); ?>

                · <?php echo e($absenHariIni->statusLabel()); ?>

            </div>
        </div>
        <?php endif; ?>
    </div>

    
    <div>
        <p style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#64748B;margin:0 0 10px 0;">
            Rekap <?php echo e(now()->isoFormat('MMMM Y')); ?>

        </p>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
            <?php
            $statCards = [
                ['label'=>'Hadir',    'value'=>$stats['hadir'],   'color'=>'#10B981','bg'=>'rgba(16,185,129,0.1)',  'icon'=>'✅'],
                ['label'=>'Alpha',    'value'=>$stats['alpha'],   'color'=>'#EF4444','bg'=>'rgba(239,68,68,0.1)',   'icon'=>'❌'],
                ['label'=>'Telat',    'value'=>$stats['telat'],   'color'=>'#F59E0B','bg'=>'rgba(245,158,11,0.1)',  'icon'=>'⏰'],
            ];
            ?>
            <?php $__currentLoopData = $statCards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="stat-card" style="text-align:center;padding:14px 8px;">
                <div style="font-size:20px;margin-bottom:6px;"><?php echo e($sc['icon']); ?></div>
                <div style="font-size:20px;font-weight:700;color:<?php echo e($sc['color']); ?>;"><?php echo e($sc['value']); ?></div>
                <div style="font-size:11px;color:#64748B;"><?php echo e($sc['label']); ?></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <?php if(auth()->user()->level == 1): ?>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px;">
            <div class="stat-card" style="padding:14px;">
                <div style="font-size:11px;color:#64748B;margin-bottom:4px;">Total Uang Makan</div>
                <div style="font-size:15px;font-weight:700;color:#C9A84C;">Rp <?php echo e(number_format($stats['total_uang_makan'],0,',','.')); ?></div>
            </div>
            <div class="stat-card" style="padding:14px;">
                <div style="font-size:11px;color:#64748B;margin-bottom:4px;">Potongan Telat</div>
                <div style="font-size:15px;font-weight:700;color:#EF4444;">Rp <?php echo e(number_format($stats['total_potongan'],0,',','.')); ?></div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    
    <div>
        <p style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#64748B;margin:0 0 10px 0;">Riwayat Absensi</p>

        <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="stat-card" style="display:flex;align-items:center;gap:14px;padding:14px 16px;margin-bottom:8px;">
            
            <div style="width:44px;text-align:center;flex-shrink:0;">
                <div style="font-size:18px;font-weight:700;line-height:1;color:<?php echo e($r->statusColor()); ?>;"><?php echo e($r->tanggal->format('d')); ?></div>
                <div style="font-size:10px;color:#64748B;text-transform:uppercase;"><?php echo e($r->tanggal->isoFormat('MMM')); ?></div>
            </div>

            
            <div style="flex:1;min-width:0;">
                <div style="font-size:13px;font-weight:600;margin-bottom:3px;" :style="darkMode ? 'color:#F1F5F9' : 'color:#1E293B'">
                    <?php echo e($r->statusLabel()); ?>

                    <?php if($r->dikoreksi): ?>
                    <span style="font-size:10px;color:#94A3B8;margin-left:4px;">· dikoreksi</span>
                    <?php endif; ?>
                </div>
                <div style="font-size:12px;color:#94A3B8;">
                    <?php if($r->jam_masuk): ?>
                    Masuk <?php echo e(substr($r->jam_masuk,0,5)); ?>

                    <?php if($r->jam_pulang): ?> · Pulang <?php echo e(substr($r->jam_pulang,0,5)); ?> <?php endif; ?>
                    <?php else: ?>
                    Tidak ada catatan
                    <?php endif; ?>
                </div>
            </div>

            
            <span style="font-size:10px;font-weight:700;padding:3px 10px;border-radius:20px;flex-shrink:0;background:<?php echo e($r->statusColor()); ?>20;color:<?php echo e($r->statusColor()); ?>;border:1px solid <?php echo e($r->statusColor()); ?>40;">
                <?php if($r->potongan_telat > 0): ?> -Rp<?php echo e(number_format($r->potongan_telat/1000,0)); ?>rb <?php else: ?> &nbsp;&nbsp;&nbsp; <?php endif; ?>
            </span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="stat-card" style="text-align:center;padding:40px;">
            <div style="font-size:32px;margin-bottom:12px;">📅</div>
            <div style="font-size:14px;font-weight:600;color:#64748B;">Belum ada riwayat absensi</div>
        </div>
        <?php endif; ?>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\canopi-app\resources\views/absensi/index.blade.php ENDPATH**/ ?>