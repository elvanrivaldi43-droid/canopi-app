

<?php $__env->startSection('page-title', 'Tambah Karyawan'); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('partials.sidebar-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-nav'); ?>
    <?php echo $__env->make('partials.bottomnav-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:680px;margin:0 auto;">

    
    <a href="<?php echo e(route('karyawan.index')); ?>" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;color:#94A3B8;text-decoration:none;margin-bottom:20px;">
        <svg xmlns="http://www.w3.org/2000/svg" style="width:16px;height:16px;" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5L3 12m0 0l7.5-7.5M3 12h18"/>
        </svg>
        Kembali ke Daftar Karyawan
    </a>

    <form method="POST" action="<?php echo e(route('karyawan.store')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <div class="stat-card" style="margin-bottom:16px;">
            <h3 style="font-size:14px;font-weight:700;margin:0 0 20px 0;padding-bottom:12px;border-bottom:1px solid rgba(255,255,255,0.06);"
                :style="darkMode ? 'color:#F1F5F9;border-color:rgba(255,255,255,0.06)' : 'color:#1E293B;border-color:#F1F5F9'">
                👤 Data Pribadi
            </h3>

            
            <div style="margin-bottom:20px;text-align:center;" x-data="{ preview: null }">
                <div style="width:80px;height:80px;border-radius:50%;margin:0 auto 12px;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;background:linear-gradient(135deg,#C9A84C,#A8872E);color:white;overflow:hidden;cursor:pointer;" onclick="document.getElementById('foto').click()">
                    <img x-show="preview" :src="preview" style="width:100%;height:100%;object-fit:cover;">
                    <span x-show="!preview">+</span>
                </div>
                <input type="file" id="foto" name="foto" accept="image/*" style="display:none;"
                       @change="const file = $event.target.files[0]; if(file) { const reader = new FileReader(); reader.onload = e => preview = e.target.result; reader.readAsDataURL(file); }">
                <div style="font-size:12px;color:#94A3B8;">Tap untuk upload foto</div>
                <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="font-size:11px;color:#F87171;margin-top:4px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php
            $fields = [
                ['name'=>'name','label'=>'Nama Lengkap','type'=>'text','placeholder'=>'Nama lengkap karyawan','required'=>true],
                ['name'=>'email','label'=>'Email','type'=>'email','placeholder'=>'email@kanopibsd.co.id','required'=>true],
                ['name'=>'password','label'=>'Password Awal','type'=>'password','placeholder'=>'Min. 6 karakter','required'=>true],
                ['name'=>'no_hp','label'=>'No. HP (WhatsApp)','type'=>'text','placeholder'=>'08xxxxxxxxxx','required'=>true],
                ['name'=>'alamat','label'=>'Alamat','type'=>'text','placeholder'=>'Alamat lengkap','required'=>false],
            ];
            ?>

            <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">
                    <?php echo e($f['label']); ?> <?php if($f['required']): ?><span style="color:#EF4444;">*</span><?php endif; ?>
                </label>
                <input type="<?php echo e($f['type']); ?>" name="<?php echo e($f['name']); ?>"
                       value="<?php echo e(old($f['name'])); ?>"
                       placeholder="<?php echo e($f['placeholder']); ?>"
                       <?php echo e($f['required'] ? 'required' : ''); ?>

                       style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                       :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                <?php $__errorArgs = [$f['name']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="font-size:11px;color:#F87171;margin-top:4px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="stat-card" style="margin-bottom:16px;">
            <h3 style="font-size:14px;font-weight:700;margin:0 0 20px 0;padding-bottom:12px;border-bottom:1px solid;"
                :style="darkMode ? 'color:#F1F5F9;border-color:rgba(255,255,255,0.06)' : 'color:#1E293B;border-color:#F1F5F9'">
                💼 Data Pekerjaan
            </h3>

            
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Level <span style="color:#EF4444;">*</span></label>
                <select name="level" required
                        style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;cursor:pointer;"
                        :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                    <option value="">Pilih level</option>
                    <?php $__currentLoopData = [1=>'Owner',2=>'Admin Operasional',3=>'Supervisor Lapangan',4=>'Marketing',5=>'Teknisi',6=>'Driver',7=>'Admin Toko Besi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($l); ?>" <?php echo e(old('level') == $l ? 'selected' : ''); ?>>Level <?php echo e($l); ?> — <?php echo e($n); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="font-size:11px;color:#F87171;margin-top:4px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Jabatan <span style="color:#EF4444;">*</span></label>
                <input type="text" name="jabatan" value="<?php echo e(old('jabatan')); ?>" placeholder="cth: Tukang Las, Admin Sales, Surveyor" required
                       style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                       :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div style="font-size:11px;color:#F87171;margin-top:4px;"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Tanggal Masuk Kerja <span style="color:#EF4444;">*</span></label>
                <input type="date" name="tgl_masuk_kerja" value="<?php echo e(old('tgl_masuk_kerja', now()->format('Y-m-d'))); ?>" required
                       style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                       :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
            </div>

            
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
                <div>
                    <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Jam Masuk</label>
                    <input type="time" name="jam_masuk" value="<?php echo e(old('jam_masuk', '07:30')); ?>" required
                           style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                           :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                </div>
                <div>
                    <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Jam Pulang</label>
                    <input type="time" name="jam_pulang" value="<?php echo e(old('jam_pulang', '17:00')); ?>" required
                           style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                           :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                </div>
            </div>
        </div>

        
        <?php if(auth()->user()->level == 1): ?>
        <div class="stat-card" style="margin-bottom:16px;">
            <h3 style="font-size:14px;font-weight:700;margin:0 0 20px 0;padding-bottom:12px;border-bottom:1px solid;"
                :style="darkMode ? 'color:#F1F5F9;border-color:rgba(255,255,255,0.06)' : 'color:#1E293B;border-color:#F1F5F9'">
                💰 Data Gaji <span style="font-size:11px;font-weight:400;color:#94A3B8;">(Hanya Owner yang bisa lihat)</span>
            </h3>

            
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Tipe Gaji</label>
                <div style="display:flex;gap:8px;">
                    <?php $__currentLoopData = ['harian'=>'Per Hari','bulanan'=>'Per Bulan','project'=>'Per Project']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label style="flex:1;display:flex;align-items:center;justify-content:center;gap:6px;padding:10px;border-radius:10px;border:1.5px solid;cursor:pointer;font-size:12px;font-weight:600;transition:all 0.2s;"
                           :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#94A3B8' : 'border-color:#E2E8F0;color:#64748B'"
                           x-bind:style="'<?php echo e($val); ?>' === $el.querySelector('input').checked ? 'border-color:#C9A84C;color:#C9A84C;background:rgba(201,168,76,0.1)' : ''">
                        <input type="radio" name="tipe_gaji" value="<?php echo e($val); ?>" <?php echo e(old('tipe_gaji','harian') == $val ? 'checked' : ''); ?> style="accent-color:#C9A84C;">
                        <?php echo e($label); ?>

                    </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
                <div>
                    <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Gaji Harian (Rp)</label>
                    <input type="number" name="gaji_harian" value="<?php echo e(old('gaji_harian', 0)); ?>" min="0"
                           style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                           :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                </div>
                <div>
                    <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Gaji Bulanan (Rp)</label>
                    <input type="number" name="gaji_bulanan" value="<?php echo e(old('gaji_bulanan', 0)); ?>" min="0"
                           style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                           :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                </div>
            </div>

            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Uang Makan Per Hari (Rp)</label>
                <input type="number" name="uang_makan" value="<?php echo e(old('uang_makan', 0)); ?>" min="0"
                       style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                       :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
            </div>

            
            <?php if($tunjangan->count() > 0): ?>
            <div>
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:10px;">Tunjangan Tambahan</label>
                <div style="display:flex;flex-direction:column;gap:10px;">
                    <?php $__currentLoopData = $tunjangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="display:flex;align-items:center;gap:12px;padding:12px;border-radius:10px;border:1.5px solid;"
                         :style="darkMode ? 'border-color:rgba(255,255,255,0.06)' : 'border-color:#F1F5F9'">
                        <div style="flex:1;">
                            <div style="font-size:12px;font-weight:600;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'"><?php echo e($t->nama_tunjangan); ?></div>
                            <div style="font-size:11px;color:#94A3B8;">Per <?php echo e($t->tipe == 'harian' ? 'hari' : 'bulan'); ?></div>
                        </div>
                        <input type="number" name="tunjangan[<?php echo e($t->id); ?>]"
                               value="<?php echo e(old('tunjangan.'.$t->id, $t->nominal_default)); ?>"
                               min="0" placeholder="0"
                               style="width:120px;padding:8px 12px;border-radius:8px;font-size:12px;outline:none;border:1.5px solid;background:transparent;text-align:right;"
                               :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        
        <div class="stat-card" style="margin-bottom:16px;">
            <h3 style="font-size:14px;font-weight:700;margin:0 0 20px 0;padding-bottom:12px;border-bottom:1px solid;"
                :style="darkMode ? 'color:#F1F5F9;border-color:rgba(255,255,255,0.06)' : 'color:#1E293B;border-color:#F1F5F9'">
                🏦 Data Rekening Bank
            </h3>

            
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Nama Bank</label>
                <select name="nama_bank"
                        style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;cursor:pointer;"
                        :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
                    <option value="">Pilih bank</option>
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($bank); ?>" <?php echo e(old('nama_bank') == $bank ? 'selected' : ''); ?>><?php echo e($bank); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Nomor Rekening</label>
                <input type="text" name="no_rekening" value="<?php echo e(old('no_rekening')); ?>" placeholder="xxxx xxxx xxxx"
                       style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                       :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
            </div>

            <div>
                <label style="display:block;font-size:12px;font-weight:600;color:#94A3B8;margin-bottom:6px;">Atas Nama</label>
                <input type="text" name="atas_nama" value="<?php echo e(old('atas_nama')); ?>" placeholder="Nama sesuai buku tabungan"
                       style="width:100%;padding:11px 14px;border-radius:10px;font-size:13px;outline:none;border:1.5px solid;background:transparent;"
                       :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#E2E8F0;' : 'border-color:#E2E8F0;color:#1E293B;'">
            </div>
        </div>

        
        <div style="display:flex;gap:10px;">
            <a href="<?php echo e(route('karyawan.index')); ?>"
               style="flex:1;display:flex;align-items:center;justify-content:center;padding:14px;border-radius:12px;font-size:13px;font-weight:600;text-decoration:none;border:1.5px solid;text-align:center;"
               :style="darkMode ? 'border-color:rgba(255,255,255,0.1);color:#94A3B8' : 'border-color:#E2E8F0;color:#64748B'">
                Batal
            </a>
            <button type="submit"
                    style="flex:2;padding:14px;border-radius:12px;font-size:13px;font-weight:700;border:none;cursor:pointer;color:#0F1117;background:linear-gradient(135deg,#C9A84C,#A8872E);">
                Simpan Karyawan
            </button>
        </div>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\canopi-app\resources\views/karyawan/create.blade.php ENDPATH**/ ?>