<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('sidebar-menu'); ?>
    <?php echo $__env->make('partials.sidebar-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom-nav'); ?>
    <?php echo $__env->make('partials.bottomnav-owner', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;flex-direction:column;gap:16px;">

    
    <div style="border-radius:16px;padding:20px;position:relative;overflow:hidden;background:linear-gradient(135deg,#0F1117 0%,#1E2535 100%);border:1px solid rgba(201,168,76,0.2)">
        <p style="font-size:12px;font-weight:600;color:var(--gold);margin:0 0 4px 0;">Selamat datang kembali 👋</p>
        <h2 class="font-display" style="font-size:22px;font-weight:700;color:white;margin:0 0 4px 0;"><?php echo e(auth()->user()->name); ?></h2>
        <p style="font-size:12px;color:#94A3B8;margin:0;"><?php echo e(now()->isoFormat('dddd, D MMMM Y')); ?> · Pusat Kanopi BSD</p>
    </div>

    
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:12px;">
        <?php
        $stats = [
            ['label'=>'Project Aktif','value'=>'0','icon'=>'🏗️','color'=>'#3B82F6','bg'=>'rgba(59,130,246,0.1)'],
            ['label'=>'Leads Bulan Ini','value'=>'0','icon'=>'📊','color'=>'#10B981','bg'=>'rgba(16,185,129,0.1)'],
            ['label'=>'Pendapatan','value'=>'Rp 0','icon'=>'💰','color'=>'#C9A84C','bg'=>'rgba(201,168,76,0.1)'],
            ['label'=>'Karyawan','value'=>'0','icon'=>'👥','color'=>'#8B5CF6','bg'=>'rgba(139,92,246,0.1)'],
        ];
        ?>
        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="stat-card">
            <div style="width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;margin-bottom:10px;background:<?php echo e($stat['bg']); ?>"><?php echo e($stat['icon']); ?></div>
            <div style="font-size:20px;font-weight:700;margin-bottom:2px;color:<?php echo e($stat['color']); ?>"><?php echo e($stat['value']); ?></div>
            <div style="font-size:11px;color:#94A3B8;"><?php echo e($stat['label']); ?></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div>
        <p style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#64748B;margin:0 0 10px 0;">Akses Cepat</p>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;">
            <?php
            $qa = [
                ['label'=>'Buat RAB','icon'=>'📝','color'=>'#C9A84C'],
                ['label'=>'Pipeline','icon'=>'📈','color'=>'#3B82F6'],
                ['label'=>'Karyawan','icon'=>'👥','color'=>'#10B981'],
                ['label'=>'Penggajian','icon'=>'💵','color'=>'#8B5CF6'],
                ['label'=>'Kasbon','icon'=>'💳','color'=>'#F59E0B'],
                ['label'=>'Laporan','icon'=>'📊','color'=>'#EF4444'],
            ];
            ?>
            <?php $__currentLoopData = $qa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button class="stat-card" style="text-align:center;padding:14px 8px;cursor:pointer;border:none;background:white;" :style="darkMode ? 'background:var(--dark3)' : 'background:white'">
                <div style="font-size:22px;margin-bottom:6px;"><?php echo e($item['icon']); ?></div>
                <div style="font-size:11px;font-weight:600;color:<?php echo e($item['color']); ?>"><?php echo e($item['label']); ?></div>
            </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    
    <div class="stat-card" style="border:1px solid rgba(201,168,76,0.2);">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;">
            <span style="font-size:18px;">🚀</span>
            <span style="font-size:13px;font-weight:700;" :style="darkMode ? 'color:#E2E8F0' : 'color:#1E293B'">Sistem Sedang Dibangun</span>
        </div>
        <p style="font-size:12px;line-height:1.6;margin:0 0 10px 0;color:#94A3B8;">
            Fondasi Laravel berhasil. Modul ditambahkan bertahap.
        </p>
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
            <?php $__currentLoopData = ['RAB','Pipeline','Smart Work','Absensi','Gaji','KPI']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <span style="font-size:11px;padding:3px 10px;border-radius:20px;background:rgba(201,168,76,0.1);color:var(--gold);border:1px solid rgba(201,168,76,0.2)"><?php echo e($m); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\canopi-app\resources\views/dashboard/owner.blade.php ENDPATH**/ ?>