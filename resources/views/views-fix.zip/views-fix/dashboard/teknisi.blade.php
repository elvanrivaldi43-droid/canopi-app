@extends('layouts.app')

@section('page-title', 'Dashboard Teknisi')

@section('sidebar-menu')
    @include('partials.sidebar-owner')
@endsection

@section('bottom-nav')
    @include('partials.bottomnav-karyawan')
@endsection

@section('content')
<div style="display:flex;flex-direction:column;gap:16px;max-width:600px;margin:0 auto;">

    {{-- Selamat datang --}}
    <div style="border-radius:16px;padding:20px;background:linear-gradient(135deg,#0F1117 0%,#1E2535 100%);border:1px solid rgba(201,168,76,0.2);">
        <p style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#C9A84C;margin:0 0 4px 0;">
            {{ now()->isoFormat('dddd, D MMMM Y') }}
        </p>
        <h2 style="font-size:18px;font-weight:700;color:white;margin:0 0 4px 0;">
            Halo, {{ auth()->user()->name }}! 👋
        </h2>
        <p style="font-size:13px;color:#64748B;margin:0;">
            {{ auth()->user()->jabatan }} · {{ auth()->user()->namaLevel() }}
        </p>
    </div>

    {{-- Status Absen Hari Ini --}}
    @php $absen = auth()->user()->absensiHariIni; @endphp
    <div style="border-radius:12px;padding:16px;
        @if(!$absen || !$absen->jam_masuk) background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);
        @elseif($absen->jam_masuk && !$absen->jam_pulang) background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);
        @else background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);
        @endif">
        <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
                <div style="font-size:12px;color:#94A3B8;margin-bottom:4px;">📋 Absensi Hari Ini</div>
                @if(!$absen || !$absen->jam_masuk)
                    <div style="font-weight:700;color:#EF4444;">Belum Absen!</div>
                @elseif($absen->jam_masuk && !$absen->jam_pulang)
                    <div style="font-weight:700;color:#F59E0B;">Masuk {{ substr($absen->jam_masuk,0,5) }} · Belum Pulang</div>
                @else
                    <div style="font-weight:700;color:#10B981;">Lengkap ✓ {{ substr($absen->jam_masuk,0,5) }}–{{ substr($absen->jam_pulang,0,5) }}</div>
                @endif
            </div>
            <a href="{{ route('absensi.index') }}"
               style="background:#fbbf24;color:#0f172a;border:none;border-radius:8px;padding:8px 16px;font-size:13px;font-weight:600;text-decoration:none;">
                {{ !$absen || !$absen->jam_masuk ? 'Absen Sekarang' : 'Lihat Detail' }}
            </a>
        </div>
    </div>

    {{-- BANNER BINTANG (tampil jika karyawan adalah bintang bulan lalu) --}}
    @php
        $bulanLalu = now()->month - 1 ?: 12;
        $tahunLalu = now()->month - 1 ? now()->year : now()->year - 1;
        $isBintang = \App\Models\KpiKinerja::where('user_id', auth()->id())
            ->where('bulan', $bulanLalu)
            ->where('tahun', $tahunLalu)
            ->where('is_bintang_jabatan', 1)
            ->exists();
        $namaBulanLalu = \Carbon\Carbon::create($tahunLalu, $bulanLalu, 1)->locale('id')->isoFormat('MMMM YYYY');
    @endphp
    @if($isBintang)
    <div style="border-radius:14px;padding:16px;background:linear-gradient(135deg,#2d1f00,#1c1400);border:2px solid #fbbf24;text-align:center;box-shadow:0 0 20px rgba(251,191,36,0.15);">
        <div style="font-size:32px;margin-bottom:6px;">🏆</div>
        <div style="color:#fbbf24;font-size:16px;font-weight:800;">BINTANG {{ strtoupper($namaBulanLalu) }}!</div>
        <div style="color:#fde68a;font-size:13px;margin-top:4px;">Kamu yang terbaik di jabatanmu bulan lalu</div>
    </div>
    @endif

    {{-- POIN KINERJA BULAN INI --}}
    @php
        $kpiBulanIni = \App\Models\KpiKinerja::where('user_id', auth()->id())
            ->where('bulan', now()->month)
            ->where('tahun', now()->year)
            ->first();
    @endphp
    @if($kpiBulanIni)
    @php
        $poin = $kpiBulanIni->total_poin;
        $bintang = str_repeat('⭐', $kpiBulanIni->bintang);
        $barColor = $poin >= 75 ? '#fbbf24' : ($poin >= 45 ? '#60a5fa' : '#ef4444');
    @endphp
    <a href="{{ route('kpi.detail') }}" style="text-decoration:none;">
        <div style="border-radius:12px;padding:16px;background:#1e293b;border:1px solid #334155;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <div style="font-size:12px;color:#94a3b8;">📊 Poin Kinerja Bulan Ini</div>
                <div style="font-size:11px;color:#64748b;">Tap untuk detail →</div>
            </div>
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
                <div style="font-size:32px;font-weight:800;color:{{ $barColor }};">{{ $poin }}</div>
                <div>
                    <div style="font-size:16px;">{{ $bintang }}</div>
                    @if($kpiBulanIni->bonus_nominal > 0)
                    <div style="color:#fbbf24;font-size:12px;font-weight:600;">
                        Bonus: Rp {{ number_format($kpiBulanIni->bonus_nominal,0,',','.') }}
                    </div>
                    @elseif($kpiBulanIni->is_alpha)
                    <div style="color:#ef4444;font-size:12px;">Ada alpha — bonus gugur</div>
                    @endif
                </div>
            </div>
            <div style="background:#0f172a;border-radius:4px;height:6px;overflow:hidden;">
                <div style="background:{{ $barColor }};width:{{ $poin }}%;height:100%;"></div>
            </div>
        </div>
    </a>
    @endif

    {{-- Info Gaji --}}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div class="stat-card" style="padding:14px;">
            <div style="font-size:11px;color:#64748B;margin-bottom:4px;">Gaji/Hari</div>
            <div style="font-size:15px;font-weight:700;color:#C9A84C;">
                Rp {{ number_format(auth()->user()->gaji_harian ?? 0, 0, ',', '.') }}
            </div>
        </div>
        <div class="stat-card" style="padding:14px;">
            <div style="font-size:11px;color:#64748B;margin-bottom:4px;">Uang Makan/Hari</div>
            <div style="font-size:15px;font-weight:700;color:#10B981;">
                Rp {{ number_format(auth()->user()->uang_makan ?? 0, 0, ',', '.') }}
            </div>
        </div>
    </div>

    {{-- Menu Cepat --}}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <a href="{{ route('absensi.index') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">📋</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Absensi</div>
            </div>
        </a>
        <a href="{{ url('/kasbon') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">💰</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Gaji & Kasbon</div>
            </div>
        </a>
        <a href="{{ route('tugas.index') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">📝</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Tugas Harian</div>
            </div>
        </a>
        <a href="{{ route('kpi.detail') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">🏆</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">KPI & Bonus</div>
            </div>
        </a>
    </div>

    {{-- UJIAN ONLINE (tampil hanya jika ujian sedang dibuka) --}}
    @php
        $periode = now()->month <= 6 ? 'januari' : 'juli';
        $ujianDibuka = \Illuminate\Support\Facades\DB::table('kpi_setting')
            ->where('key_setting', 'ujian_dibuka_' . $periode . '_' . now()->year)
            ->value('value_setting');
        $sudahUjian = \App\Models\UjianSesi::where('user_id', auth()->id())
            ->where('periode', $periode)
            ->where('tahun', now()->year)
            ->whereIn('status', ['selesai', 'berlangsung'])
            ->exists();
    @endphp
    @if($ujianDibuka === '1' && !$sudahUjian)
    <a href="{{ route('kpi.ujian.index') }}" style="text-decoration:none;">
        <div style="border-radius:12px;padding:16px;background:linear-gradient(135deg,#1a1a2e,#16213e);border:2px solid #fbbf24;display:flex;align-items:center;gap:14px;">
            <div style="font-size:32px;">📝</div>
            <div style="flex:1;">
                <div style="color:#fbbf24;font-weight:700;font-size:15px;">Ujian Online Tersedia!</div>
                <div style="color:#94a3b8;font-size:12px;margin-top:2px;">Periode {{ ucfirst($periode) }} {{ now()->year }} · 20 soal · 30 menit</div>
            </div>
            <div style="color:#fbbf24;font-size:18px;">→</div>
        </div>
    </a>
    @endif

</div>
@endsection