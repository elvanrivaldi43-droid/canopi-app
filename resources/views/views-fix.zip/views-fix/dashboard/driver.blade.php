@extends('layouts.app')

@section('page-title', 'Dashboard Driver')

@section('sidebar-menu')
    @include('partials.sidebar-owner')
@endsection

@section('bottom-nav')
    @include('partials.bottomnav-karyawan')
@endsection

@section('content')
<div style="display:flex;flex-direction:column;gap:16px;max-width:600px;margin:0 auto;">

    {{-- Selamat datang --}}
    <div style="border-radius:16px;padding:20px;background:linear-gradient(135deg,#0F1117 0%,#1E2535 100%);border:1px solid rgba(201,168,76,0.2);">
        <p style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#C9A84C;margin:0 0 4px 0;">
            {{ now()->isoFormat('dddd, D MMMM Y') }}
        </p>
        <h2 style="font-size:18px;font-weight:700;color:white;margin:0 0 4px 0;">
            Halo, {{ auth()->user()->name }}! 👋
        </h2>
        <p style="font-size:13px;color:#64748B;margin:0;">
            {{ auth()->user()->jabatan }} · {{ auth()->user()->namaLevel() }}
        </p>
    </div>

    {{-- Status Absen Hari Ini --}}
    @php $absen = auth()->user()->absensiHariIni; @endphp
    <div style="border-radius:12px;padding:16px;
        @if(!$absen || !$absen->jam_masuk) background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);
        @elseif($absen->jam_masuk && !$absen->jam_pulang) background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.3);
        @else background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);
        @endif">
        <div style="display:flex;justify-content:space-between;align-items:center;">
            <div>
                <div style="font-size:12px;color:#94A3B8;margin-bottom:4px;">📋 Absensi Hari Ini</div>
                @if(!$absen || !$absen->jam_masuk)
                    <div style="font-weight:700;color:#EF4444;">Belum Absen!</div>
                @elseif($absen->jam_masuk && !$absen->jam_pulang)
                    <div style="font-weight:700;color:#F59E0B;">Masuk {{ substr($absen->jam_masuk,0,5) }} · Belum Pulang</div>
                @else
                    <div style="font-weight:700;color:#10B981;">Lengkap ✓ {{ substr($absen->jam_masuk,0,5) }}–{{ substr($absen->jam_pulang,0,5) }}</div>
                @endif
            </div>
            <a href="{{ route('absensi.index') }}"
               style="background:#fbbf24;color:#0f172a;border:none;border-radius:8px;padding:8px 16px;font-size:13px;font-weight:600;text-decoration:none;">
                {{ !$absen || !$absen->jam_masuk ? 'Absen Sekarang' : 'Lihat Detail' }}
            </a>
        </div>
    </div>

    {{-- Alert log bensin belum pulang --}}
    @php
        $logBensinAktif = \App\Models\LogBensin::where('driver_id', auth()->id())
            ->where('status', 'berangkat')
            ->whereDate('tanggal', today())
            ->first();
    @endphp
    @if($logBensinAktif)
    <div style="border-radius:12px;padding:14px 16px;background:rgba(245,158,11,0.1);border:1px solid rgba(245,158,11,0.4);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;">
        <div>
            <div style="font-size:11px;color:#94A3B8;margin-bottom:3px;">⛽ BBM Belum Dicatat Pulang</div>
            <div style="font-size:13px;font-weight:700;color:#F59E0B;">{{ $logBensinAktif->tujuan }}</div>
        </div>
        <a href="{{ route('bensin.pulang', $logBensinAktif->id) }}"
           style="background:#f59e0b;color:#0f172a;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:700;text-decoration:none;white-space:nowrap;">
            Isi KM Pulang →
        </a>
    </div>
    @endif

    {{-- Widget Tugas Hari Ini --}}
    @if(isset($tugasHariIni) && $tugasHariIni->count() > 0)
    <div style="background:#1e293b;border-radius:14px;padding:16px;border:1px solid #334155;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <div style="font-size:14px;font-weight:700;color:#fbbf24;">📋 Tugas Hari Ini</div>
            <span style="background:rgba(251,191,36,.15);color:#fbbf24;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;">
                {{ $tugasHariIni->count() }} tugas
            </span>
        </div>
        @foreach($tugasHariIni as $ta)
        @php
            $t = $ta->tugas;
            $warna = match($ta->status) {
                'selesai'       => '#22c55e',
                'dikerjakan'    => '#3b82f6',
                'tidak_selesai' => '#ef4444',
                default         => '#64748b',
            };
            $border = match($t->prioritas) {
                'tinggi' => '#ef4444',
                'sedang' => '#f59e0b',
                default  => '#22c55e',
            };
        @endphp
        <div style="background:#0f172a;border-radius:10px;padding:12px 14px;margin-bottom:8px;border-left:3px solid {{ $border }};">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px;">
                <a href="{{ route('tugas.show', $t->id) }}"
                   style="font-size:14px;font-weight:700;color:#f1f5f9;text-decoration:none;">
                    {{ $t->judul }}
                </a>
                <span style="background:{{ $warna }}20;color:{{ $warna }};font-size:11px;font-weight:600;padding:3px 8px;border-radius:20px;white-space:nowrap;flex-shrink:0;">
                    {{ $ta->labelStatus() }}
                </span>
            </div>
            @if($t->jam_mulai || $t->lokasi)
            <div style="font-size:11px;color:#64748b;margin-top:4px;">
                @if($t->jam_mulai){{ substr($t->jam_mulai,0,5) }}@endif
                @if($t->jam_mulai && $t->lokasi) · @endif
                @if($t->lokasi){{ $t->lokasi }}@endif
            </div>
            @endif
            @if($ta->status === 'belum')
            <a href="{{ route('tugas.show', $t->id) }}"
               style="display:inline-block;margin-top:8px;background:#fbbf24;color:#0f172a;font-size:11px;font-weight:700;padding:5px 12px;border-radius:8px;text-decoration:none;">
                Update Status →
            </a>
            @endif
        </div>
        @endforeach
        <a href="{{ route('tugas.index') }}"
           style="display:block;text-align:center;margin-top:4px;color:#475569;font-size:12px;text-decoration:none;">
            Lihat semua tugas →
        </a>
    </div>
    @endif

    {{-- Info Gaji --}}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <div class="stat-card" style="padding:14px;">
            <div style="font-size:11px;color:#64748B;margin-bottom:4px;">Gaji/Hari</div>
            <div style="font-size:15px;font-weight:700;color:#C9A84C;">
                Rp {{ number_format(auth()->user()->gaji_harian ?? 0, 0, ',', '.') }}
            </div>
        </div>
        <div class="stat-card" style="padding:14px;">
            <div style="font-size:11px;color:#64748B;margin-bottom:4px;">Uang Makan/Hari</div>
            <div style="font-size:15px;font-weight:700;color:#10B981;">
                Rp {{ number_format(auth()->user()->uang_makan ?? 0, 0, ',', '.') }}
            </div>
        </div>
    </div>

    {{-- Menu Cepat --}}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
        <a href="{{ route('absensi.index') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">📋</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Absensi</div>
            </div>
        </a>
        <a href="{{ route('penggajian.slip-saya') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">💰</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Gaji & Kasbon</div>
            </div>
        </a>
        <a href="{{ route('tugas.index') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">📝</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Tugas Harian</div>
            </div>
        </a>
        <a href="{{ route('bensin.create') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">⛽</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Catat BBM</div>
            </div>
        </a>
        <a href="{{ route('bensin.riwayat') }}" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;">
                <div style="font-size:28px;margin-bottom:8px;">📊</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">Riwayat BBM</div>
            </div>
        </a>
        <a href="#" style="text-decoration:none;">
            <div class="stat-card" style="text-align:center;padding:20px;cursor:pointer;opacity:0.5;">
                <div style="font-size:28px;margin-bottom:8px;">🏆</div>
                <div style="font-size:13px;font-weight:600;color:#F1F5F9;">KPI & Bonus</div>
                <div style="font-size:10px;color:#475569;margin-top:4px;">Segera hadir</div>
            </div>
        </a>
    </div>

</div>
@endsection