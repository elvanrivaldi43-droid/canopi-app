{{-- FILE: resources/views/pipeline/edit.blade.php --}}
@extends('layouts.app')
@section('page-title', 'Edit Lead')
@section('sidebar-menu')
    @include('partials.sidebar-owner')
@endsection
@section('bottom-nav')
    @include('partials.bottomnav')
@endsection
@section('content')
<div style="max-width:600px;margin:0 auto;">

    <a href="{{ route('pipeline.show', $pipeline) }}" style="display:inline-flex;align-items:center;gap:6px;font-size:13px;color:#64748b;text-decoration:none;margin-bottom:20px;">
        ← Kembali ke Detail
    </a>

    @if($errors->any())
    <div style="background:rgba(239,68,68,0.1);border:1px solid #ef4444;border-radius:10px;padding:14px;margin-bottom:16px;">
        @foreach($errors->all() as $e)
        <div style="font-size:12px;color:#fca5a5;">• {{ $e }}</div>
        @endforeach
    </div>
    @endif

    <form method="POST" action="{{ route('pipeline.update', $pipeline) }}">
        @csrf
        @method('PUT')

        <div class="stat-card" style="margin-bottom:14px;">
            <div style="font-size:13px;font-weight:700;color:#fbbf24;margin-bottom:16px;">👤 Data Customer</div>

            <div style="margin-bottom:12px;">
                <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">Nama Customer *</label>
                <input type="text" name="nama_customer" value="{{ old('nama_customer', $pipeline->nama_customer) }}" required
                    style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;">
            </div>

            <div style="margin-bottom:12px;">
                <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">No. HP *</label>
                <input type="text" name="no_hp" value="{{ old('no_hp', $pipeline->no_hp) }}" required
                    style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;">
            </div>

            <div style="margin-bottom:12px;">
                <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">Alamat Lokasi</label>
                <textarea name="alamat" rows="2"
                    style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;resize:none;">{{ old('alamat', $pipeline->alamat) }}</textarea>
            </div>
        </div>

        <div class="stat-card" style="margin-bottom:14px;">
            <div style="font-size:13px;font-weight:700;color:#fbbf24;margin-bottom:16px;">🏗️ Detail Lead</div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">Produk *</label>
                    <select name="produk" required style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;">
                        @foreach($produkList as $val => $label)
                        <option value="{{ $val }}" {{ old('produk',$pipeline->produk)==$val?'selected':'' }}>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">Sumber Lead *</label>
                    <select name="sumber_lead" required style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;">
                        @foreach($sumberList as $val => $label)
                        <option value="{{ $val }}" {{ old('sumber_lead',$pipeline->sumber_lead)==$val?'selected':'' }}>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
            </div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">Status *</label>
                    <select name="status" required id="statusSelect" onchange="cekStatus(this.value)"
                        style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;">
                        @foreach($statuses as $val => $label)
                        <option value="{{ $val }}" {{ old('status',$pipeline->status)==$val?'selected':'' }}>{{ $label }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">Estimasi Nilai (Rp)</label>
                    <input type="number" name="estimasi_nilai" value="{{ old('estimasi_nilai', $pipeline->estimasi_nilai) }}" min="0"
                        style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;">
                </div>
            </div>

            <div id="jadwalWrap" style="display:{{ old('status',$pipeline->status)=='dijadwalkan'?'block':'none' }};margin-bottom:12px;">
                <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">📅 Jadwal Kunjungan</label>
                <input type="datetime-local" name="tgl_kunjungan" value="{{ old('tgl_kunjungan', $pipeline->tgl_kunjungan?->format('Y-m-d\TH:i')) }}"
                    style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;">
            </div>

            <div>
                <label style="font-size:12px;color:#64748b;display:block;margin-bottom:6px;">Catatan</label>
                <textarea name="catatan" rows="3"
                    style="width:100%;background:#0f172a;border:1px solid #334155;color:#f1f5f9;border-radius:8px;padding:10px 12px;font-size:13px;resize:none;">{{ old('catatan', $pipeline->catatan) }}</textarea>
            </div>
        </div>

        <div style="display:flex;gap:10px;">
            <a href="{{ route('pipeline.show', $pipeline) }}"
                style="flex:1;padding:14px;background:#334155;color:#e2e8f0;border-radius:10px;font-size:13px;font-weight:600;text-decoration:none;text-align:center;">
                Batal
            </a>
            <button type="submit"
                style="flex:2;padding:14px;background:#fbbf24;color:#0f172a;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;">
                💾 Simpan Perubahan
            </button>
        </div>
    </form>
</div>

<script>
function cekStatus(val) {
    document.getElementById('jadwalWrap').style.display = val === 'dijadwalkan' ? 'block' : 'none';
}
</script>
@endsection