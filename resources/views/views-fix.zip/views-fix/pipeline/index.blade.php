{{-- FILE: resources/views/pipeline/index.blade.php --}}
@extends('layouts.app')
@section('page-title', 'Pipeline Survey')
@section('sidebar-menu')
    @include('partials.sidebar-owner')
@endsection
@section('bottom-nav')
    @include('partials.bottomnav')
@endsection
@section('content')
<style>
.kanban-wrap { display:flex; gap:12px; overflow-x:auto; padding-bottom:20px; min-height:70vh; }
.kanban-col { min-width:260px; max-width:260px; background:#1e293b; border-radius:12px; padding:12px; flex-shrink:0; }
.kanban-header { font-size:11px; font-weight:700; text-transform:uppercase; letter-spacing:1px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center; }
.kanban-count { background:rgba(255,255,255,0.1); border-radius:20px; padding:2px 8px; font-size:11px; }
.lead-card { background:#0f172a; border-radius:10px; padding:12px; margin-bottom:8px; border-left:3px solid; cursor:pointer; transition:transform 0.15s; text-decoration:none; display:block; }
.lead-card:hover { transform:translateY(-2px); }
.lead-nama { font-size:13px; font-weight:700; color:#f1f5f9; margin-bottom:4px; }
.lead-hp { font-size:11px; color:#64748b; }
.lead-produk { font-size:10px; padding:2px 8px; border-radius:20px; background:rgba(251,191,36,0.15); color:#fbbf24; display:inline-block; margin-top:6px; }
.lead-nilai { font-size:12px; color:#10b981; font-weight:600; margin-top:4px; }
.aging-badge { font-size:10px; background:rgba(239,68,68,0.2); color:#ef4444; border-radius:20px; padding:2px 8px; display:inline-block; margin-top:4px; }
.jadwal-badge { font-size:10px; background:rgba(139,92,246,0.2); color:#8b5cf6; border-radius:20px; padding:2px 8px; display:inline-block; margin-top:4px; }
.stat-bar { display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap; }
.stat-item { background:#1e293b; border-radius:10px; padding:10px 16px; font-size:12px; }
.kanban-cards { min-height:60px; }
.drag-ghost { opacity:0.4; }
.lead-card:active { cursor:grabbing; }
</style>

{{-- Alert --}}
@if(session('success'))
<div style="background:rgba(16,185,129,0.15);border:1px solid #10b981;color:#6ee7b7;border-radius:10px;padding:12px;margin-bottom:16px;font-size:13px;">
    ✅ {{ session('success') }}
</div>
@endif

{{-- Header --}}
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
    <div>
        <div style="font-size:20px;font-weight:800;color:#f1f5f9;">🎯 Pipeline Survey</div>
        <div style="font-size:12px;color:#64748b;">Total potensi: <span style="color:#10b981;font-weight:700;">Rp {{ number_format($totalNilai,0,',','.') }}</span></div>
    </div>
    <div style="display:flex;gap:8px;">
        <a href="{{ route('pipeline.list') }}" style="padding:8px 14px;background:#334155;color:#e2e8f0;border-radius:8px;font-size:12px;font-weight:600;text-decoration:none;">📋 List</a>
        <a href="{{ route('pipeline.create') }}" style="padding:8px 14px;background:#fbbf24;color:#0f172a;border-radius:8px;font-size:12px;font-weight:700;text-decoration:none;">+ Tambah Lead</a>
    </div>
</div>

{{-- Stats Bar --}}
<div class="stat-bar">
    @foreach($statuses as $key => $label)
    @php $count = $grouped[$key]->count(); $color = $colors[$key]; @endphp
    <div class="stat-item" style="border-left:3px solid {{ $color }};">
        <span style="color:{{ $color }};font-weight:700;">{{ $count }}</span>
        <span style="color:#64748b;margin-left:4px;">{{ $label }}</span>
    </div>
    @endforeach
</div>

{{-- Kanban Board --}}
<div class="kanban-wrap">
    @foreach($statuses as $key => $label)
    @php $color = $colors[$key]; $cards = $grouped[$key]; @endphp
    <div class="kanban-col">
        <div class="kanban-header" style="color:{{ $color }};">
            <span>{{ $label }}</span>
            <span class="kanban-count">{{ $cards->count() }}</span>
        </div>

        <div class="kanban-cards" data-status="{{ $key }}">
        @foreach($cards as $lead)
        <a href="{{ route('pipeline.show', $lead) }}" class="lead-card" data-id="{{ $lead->id }}" style="border-left-color:{{ $color }};">
            <div class="lead-nama">{{ $lead->nama_customer }}</div>
            <div class="lead-hp">📱 {{ $lead->no_hp }}</div>
            <div>
                <span class="lead-produk">{{ $lead->produkLabel() }}</span>
            </div>
            @if($lead->estimasi_nilai > 0)
            <div class="lead-nilai">Rp {{ number_format($lead->estimasi_nilai,0,',','.') }}</div>
            @endif
            @if($lead->tgl_kunjungan && $key === 'dijadwalkan')
            <div class="jadwal-badge">📅 {{ $lead->tgl_kunjungan->format('d/m H:i') }}</div>
            @endif
            @if($lead->is_aging)
            <div class="aging-badge">⚠️ {{ $lead->aging }} hari</div>
            @endif
            <div style="font-size:10px;color:#475569;margin-top:6px;">
                {{ $lead->sumberLabel() }} · {{ $lead->updated_at->diffForHumans() }}
            </div>
        </a>
        @endforeach
        </div>
    </div>
    @endforeach
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js"></script>
<script>
(function(){
    if(typeof Sortable === 'undefined'){ return; }
    var CSRF='{{ csrf_token() }}';
    var cols=document.querySelectorAll('.kanban-cards');
    for(var i=0;i<cols.length;i++){
        new Sortable(cols[i], {
            group:'pipeline',
            animation:150,
            delay:150,
            delayOnTouchOnly:true,
            draggable:'.lead-card',
            ghostClass:'drag-ghost',
            onEnd:function(evt){
                if(evt.from===evt.to) return; // tidak pindah kolom
                var id=evt.item.getAttribute('data-id');
                var status=evt.to.getAttribute('data-status');
                fetch('{{ url("/pipeline") }}/'+id+'/status', {
                    method:'PATCH',
                    headers:{'Content-Type':'application/json','X-CSRF-TOKEN':CSRF,'Accept':'application/json'},
                    body:JSON.stringify({ status:status })
                }).then(function(r){ return r.json(); }).then(function(res){
                    if(!res || !res.success){ alert('Gagal ubah status, halaman dimuat ulang.'); location.reload(); }
                }).catch(function(e){ alert('Error: '+e.message); location.reload(); });
            }
        });
    }
})();
</script>
@endsection